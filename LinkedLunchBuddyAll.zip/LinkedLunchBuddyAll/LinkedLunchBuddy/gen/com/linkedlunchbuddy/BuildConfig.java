/** Automatically generated file. DO NOT MODIFY */
package com.linkedlunchbuddy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}